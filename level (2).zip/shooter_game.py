#Создай собственный Шутер!

from pygame import *
